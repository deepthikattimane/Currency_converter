import javax.swing.*;
import java.awt.event.*;
import java.util.HashMap;

public class CurrencyConverter1 {
    public static void converter() {
        JFrame C = new JFrame("Currency Converter");

        JLabel l1 = new JLabel("Amount:");
        l1.setBounds(20, 40, 100, 30);
        JLabel l2 = new JLabel("From:");
        l2.setBounds(20, 80, 100, 30);
        JLabel l3 = new JLabel("To:");
        l3.setBounds(20, 120, 100, 30);
        JLabel resultLabel = new JLabel("Converted Amount:");
        resultLabel.setBounds(20, 180, 300, 30);

        JTextField amountField = new JTextField("0");
        amountField.setBounds(120, 40, 100, 30);

        String[] currencies = {"INR", "USD", "EUR", "GBP", "JPY"};
        JComboBox<String> fromCurrency = new JComboBox<>(currencies);
        fromCurrency.setBounds(120, 80, 100, 30);
        JComboBox<String> toCurrency = new JComboBox<>(currencies);
        toCurrency.setBounds(120, 120, 100, 30);

        JButton convertButton = new JButton("Convert");
        convertButton.setBounds(50, 150, 100, 30);
        JButton closeButton = new JButton("Close");
        closeButton.setBounds(170, 150, 100, 30);

        // Exchange rates map
        HashMap<String, Double> exchangeRates = new HashMap<>();
        exchangeRates.put("INR-USD", 0.012); exchangeRates.put("INR-EUR", 0.011);
        exchangeRates.put("INR-GBP", 0.0095); exchangeRates.put("INR-JPY", 1.50);
        exchangeRates.put("USD-INR", 82.5); exchangeRates.put("USD-EUR", 0.92);
        exchangeRates.put("USD-GBP", 0.76); exchangeRates.put("USD-JPY", 110.0);
        exchangeRates.put("EUR-INR", 89.0); exchangeRates.put("EUR-USD", 1.09);
        exchangeRates.put("EUR-GBP", 0.83); exchangeRates.put("EUR-JPY", 120.0);
        exchangeRates.put("GBP-INR", 105.0); exchangeRates.put("GBP-USD", 1.32);
        exchangeRates.put("GBP-EUR", 1.20); exchangeRates.put("GBP-JPY", 140.0);
        exchangeRates.put("JPY-INR", 0.67); exchangeRates.put("JPY-USD", 0.0091);
        exchangeRates.put("JPY-EUR", 0.0083); exchangeRates.put("JPY-GBP", 0.0071);

        // Convert button action
        convertButton.addActionListener(e -> {
            try {
                double amount = Double.parseDouble(amountField.getText().trim());
                String from = (String) fromCurrency.getSelectedItem();
                String to = (String) toCurrency.getSelectedItem();

                if (from.equals(to)) {
                    resultLabel.setText("Converted Amount: " + amount + " " + to);
                } else {
                    String key = from + "-" + to;
                    if (exchangeRates.containsKey(key)) {
                        double convertedAmount = amount * exchangeRates.get(key);
                        resultLabel.setText("Converted Amount: " + String.format("%.2f", convertedAmount) + " " + to);
                    } else {
                        resultLabel.setText("Conversion rate not available!");
                    }
                }
            } catch (NumberFormatException ex) {
                resultLabel.setText("Invalid input! Enter a valid number.");
            }
        });

        closeButton.addActionListener(e -> C.dispose());

        C.add(l1); C.add(amountField);
        C.add(l2); C.add(fromCurrency);
        C.add(l3); C.add(toCurrency);
        C.add(convertButton); C.add(closeButton);
        C.add(resultLabel);

        C.setLayout(null);
        C.setSize(350, 300);
        C.setLocationRelativeTo(null); // Center the window
        C.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Proper closing
        C.setVisible(true);
    }

    public static void main(String[] args) {
        // Run on Event Dispatch Thread
        SwingUtilities.invokeLater(CurrencyConverter1::converter);
    }
}
